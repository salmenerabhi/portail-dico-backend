#!/usr/bin/perl -w

use warnings;
use XML::Twig;
use Cwd;
use File::Copy;
use Encode 'encode';
use Win32::OLE qw(in with);
use Win32::OLE::Const;
use Win32::OLE::Variant;
use Archive::Zip;
use Time::HiRes;
use DBI;
use OLE;

my $config_file;#fichier de configuration qui définit quels sont les codes à remplacer
my @Filesmpm;
my @Filesfnc;
my @Filesmenu;
my $contientMD14;
my $dicoName;
my %hashDicos=();
my $nbTTBT=0;
my @dicos=();
main();
sub main
{

	#system("cls");
	checkArguments();
	#parse_config_file();
	@Filesmpm = GetFilesList ("$ARGV[0]");
	Replace_codes ('GPC',@Filesmpm);
    @Filesfnc = GetFilesList ("$ARGV[1]");
	Replace_codes ('FNC',@Filesfnc);
	@Filesmenu = GetFilesList ("$ARGV[2]");
	print "\n******************Recherche dans le menu******************\n";
	Replace_codes ('Menu',@Filesmenu);
	print "\n******************Recherche terminé******************\n"; 
	

}


sub GetFilesList 
{
        my $Path = $_[0];
		my $FileFound;
		my @FilesList=();
        opendir (my $FhRep, $Path)
                or die "Impossible d'ouvrir le repertoire $Path\n";
        my @Contenu = grep { !/^\.\.?$/ } readdir($FhRep);
        closedir ($FhRep);

        foreach my $FileFound (@Contenu) 
		{
                if ( (-f "$Path/$FileFound")&&( $FileFound ne "Vehicule.xml" ))
				{
                        push ( @FilesList, "$Path/$FileFound" );
						
                }
                elsif ( (-d "$Path/$FileFound") && ($FileFound ne "CFGECUTYPE") && ($FileFound ne "VEH_ARCH")&& ($FileFound ne ".svn")&& ($FileFound ne ".zip")) {
                        push (@FilesList, GetFilesList("$Path/$FileFound") );
                }
        }
        return @FilesList;
}

sub Replace_codes
{

    my ($type,@liste) = @_; 
    
	#print $type;
	#sleep 10;
	my $nb=1;
	my $FileTmp;
	if ($type eq "GPC")
	{
	#printf ("Recherche GPC ...  %3.0f%%\n",$avancement);
	$FileTmp="log_GPC.txt";
   
   	}
    if ($type eq "Menu")
	{
	#printf ("Recherche Menu ...  %3.0f%%\n",$avancement);
	$FileTmp="log_Menu.txt";
   	}
	 if ($type eq "FNC")
	{
	#printf ("Recherche FNC ...  %3.0f%%\n",$avancement);
	$FileTmp="log_FNC.txt";
   	}
	open (XML_FILE, ">", $FileTmp);
	#parcourir chaque fichier de MPM ou menu ou fnc
	foreach my $file (@liste)
	{
    
	#print $file;
	$avancement= ($nb/scalar(@liste))*100;
	if ($type eq "GPC")
	{
	printf ("Recherche GPC ...  %3.0f%%\n",$avancement);
	#$FileTmp="log_GPC.txt";
   	}
    if ($type eq "Menu")
	{
	printf ("Recherche Menu ...  %3.0f%%\n",$avancement);
	#$FileTmp="log_Menu.txt";
   	}
	 if ($type eq "FNC")
	{
	printf ("Recherche FNC ...  %3.0f%%\n",$avancement);
	#$FileTmp="log_FNC.txt";
   	}
	$contientMD14=0;
	#ouverture fichier en lecture
	open(FILEIN, "<", $file) or die "Couldn't open: $!";
	# open (XML_FILE, ">>", $FileTmp);   
	#tester si le fichier ou moins un code a remplacer dans le fichier config
	
	my @lignes = <FILEIN>;
	
    foreach my $ligne(@lignes)				
	{
	 
	  #|| ($ligne !~ /\/\/(.*)\@TT/)
			if (($ligne =~ /\@TTBT/)||($ligne =~ /\@TBT/)||($ligne =~ /\@TTB/) )#s'il existe @TTBT
			{
				 
							$nbTTBT=$nbTTBT+1;
							$contientMD14= 1;
							last;
			}
	
	}
   

	
	#si le fichier contient un code à remlacer ouverture en ecriture
	if ($contientMD14==1)
	{
       
		 print XML_FILE "$file\n";
	}
	
		
	#close(XML_FILE);
	close(FILEIN);
	$nb = $nb+1;
	}

	
	print "nombre des fichiers $nb\n";
	close(XML_FILE);
	}
	


#parsing du fichier de config des codes à remplacer
sub parse_config_file
{
   


   my $twig = XML::Twig->new();	
    if (!$twig -> parsefile($config_file))
	{			
		die "\tERROR : Chargement config file <$config_file > : KO\n";
	}
	else
	{
		print "\tChargement config file  <$config_file> : OK\n";
	}
    my $root=$twig->root;
	
	foreach my $dico($root->children('Dico'))
	{
	    $dicoName=$dico->att('name');
		push (@dicos,$dicoName);#remplir les dico dans un liste
        foreach my $sentence($dico->children('sentence'))	
        {
		    
			my $sentencecode=$sentence->att('code');
		    my $unitcode=$sentence->att('unitcode');
			$hashDicos{$dicoName}{$sentencecode}=$unitcode;					
		
		}		
	}
	$twig->purge();
	$twig->dispose();
	
}


sub checkArguments
{
print"--------------------chek argument----------------------------------\n";
	if (! (scalar(@ARGV) == 4))
	{
		print("nombre de code correcte\n");
		print "Usage: We need 4 argument \n";
		print "arg1 : path of gpc directory \n";
		print "arg2 : path of fnc directory \n";
		print "arg3 : path of menu directory \n";
		print "arg4 : path of config file\n";
		print "----------------------------------\n";
		die   "ERROR : Wrong number of parameters\n";
	}


	if (!-e $ARGV[0])
	{
		die("ERROR : gpc directory not found \n");
	}
	if (!-e $ARGV[1])
	{
		die("ERROR : fnc directory not found \n");
	}
	if (!-e $ARGV[2])
	{
		die("ERROR : menu directory not found \n");
	}
	if (!-e $ARGV[3])
	{
		die("ERROR : Config file not found \n");
		
	}
	$config_file=$ARGV[3];	
}