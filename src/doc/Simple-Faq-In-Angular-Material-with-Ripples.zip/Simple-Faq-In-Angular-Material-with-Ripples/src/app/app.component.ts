import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'my-app';
  OpenState: boolean = false;

  CollapsedHeight: string = '50px';
  ExpandedHeight: string = '50px';
  
}
